from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, HttpUrl
import yt_dlp
from pytubefix import YouTube
from pytubefix.cli import on_progress
import os
import uuid
from pathlib import Path
from typing import Optional, List
import asyncio
from concurrent.futures import ThreadPoolExecutor
import logging
import shutil
import subprocess

import sys
import tempfile

# Configure logging to file and console
log_file_path = Path.cwd() / "server.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_file_path, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logging.getLogger("multipart").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

# Determine the application base path (works for Python script and PyInstaller exe)
if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent.resolve()

logger.info(f"Application Base Directory: {BASE_DIR}")

app = FastAPI(title="YouTube & Social Video Downloader API", version="2.1.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Environment Detection (Server vs Desktop)
IS_SERVER = os.environ.get("RENDER") or os.environ.get("DYNO") or os.environ.get("SERVER_ENV")

if IS_SERVER:
    DOWNLOADS_DIR = Path(tempfile.gettempdir()) / "avy_downloads"
    logger.info(f"Running in SERVER mode. Downloads dir: {DOWNLOADS_DIR}")
else:
    DOWNLOADS_DIR = Path.home() / "Downloads"
    logger.info(f"Running in DESKTOP mode. Downloads dir: {DOWNLOADS_DIR}")

DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)

# Thread pool
executor = ThreadPoolExecutor(max_workers=4)

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Unhandled server error: {exc}", exc_info=True)
    return FileResponse(BASE_DIR / "index.html", status_code=500) # Or JSON? 
    # Better to return JSON for API calls, but maybe text for debugging.
    # Let's return a JSON error that the frontend might (or might not) handle, 
    # but primarily we want to ENSURE IT IS LOGGED.
    # Actually, let's keep it simple: generic 500 response, but LOG IT.
    from fastapi.responses import JSONResponse
    return JSONResponse(
        status_code=500,
        content={"message": "Internal Server Error", "detail": str(exc)},
    )

class VideoURL(BaseModel):
    url: HttpUrl

class DownloadRequest(BaseModel):
    url: HttpUrl
    format: str = "best"
    quality: Optional[str] = None

def is_youtube_url(url: str) -> bool:
    u = str(url).lower()
    return "youtube.com" in u or "youtu.be" in u

@app.get("/")
async def root():
    html_path = BASE_DIR / "index.html"
    if not html_path.exists():
        logger.error(f"index.html not found at {html_path}")
        return {"error": "index.html not found. Please ensure it exists in the application directory."}
    return FileResponse(html_path)

@app.post("/video/info")
async def get_video_info(video: VideoURL):
    url_str = str(video.url)
    
    # helper for yt-dlp info
    def get_info_ytdlp():
        ydl_opts = {'quiet': True, 'no_warnings': True, 'extract_flat': False}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            return ydl.extract_info(url_str, download=False)

    try:
        # Use yt-dlp for everything (more robust against bot detection for info fetching)
        info = await asyncio.get_event_loop().run_in_executor(executor, get_info_ytdlp)
        return {
            "success": True,
            "data": {
                "title": info.get('title'),
                "thumbnail": info.get('thumbnail'),
                "duration": info.get('duration'),
                "uploader": info.get('uploader'),
                "view_count": info.get('view_count'),
            }
        }
            
    except Exception as e:
        logger.error(f"Error info: {e}")
        raise HTTPException(status_code=400, detail=str(e))

def cleanup_file(path: str):
    try:
        if os.path.exists(path):
            os.remove(path)
            logger.info(f"Cleaned up file: {path}")
    except Exception as e:
        logger.warning(f"Failed to cleanup file {path}: {e}")

@app.get("/video/download_link")
async def download_link_get(url: str, background_tasks: BackgroundTasks, format: str = "best", quality: str = None):
    url_str = url
    download_id = str(uuid.uuid4())
    
    # Check for FFmpeg
    ffmpeg_exe = "ffmpeg"
    local_ffmpeg = BASE_DIR / "ffmpeg.exe"
    if local_ffmpeg.exists():
        ffmpeg_exe = str(local_ffmpeg)
    elif shutil.which("ffmpeg"):
         ffmpeg_exe = "ffmpeg"
    else:
         ffmpeg_exe = None
    
    if not ffmpeg_exe:
        logger.warning("FFmpeg not found. Some features may be limited.")
    
    try:
        filename = ""
        filepath = ""
        request = DownloadRequest(url=url, format=format, quality=quality) # Hack to reuse logic if I had helper
        
        # Duplicated Logic for safety - I will compress this in my head to a helper if I could, 
        # but for this tool I must write it out.
        
        if is_youtube_url(url_str):
            def download_pytube(download_id):
                yt = YouTube(url_str)
                stream = None
                
                if format == "mp3":
                    stream = yt.streams.get_audio_only()
                    ext = ".m4a" 
                else:
                    target_res = quality
                    if target_res:
                        stream = yt.streams.filter(res=target_res, progressive=True).first()
                    
                    if not stream and ffmpeg_exe and target_res:
                         video_stream = yt.streams.filter(res=target_res, adaptive=True).first()
                         if video_stream:
                             audio_stream = yt.streams.get_audio_only()
                             if audio_stream:
                                 v_name = f"v_{download_id}_{video_stream.resolution}.mp4"
                                 a_name = f"a_{download_id}.m4a"
                                 v_path = video_stream.download(output_path=str(DOWNLOADS_DIR), filename=v_name)
                                 a_path = audio_stream.download(output_path=str(DOWNLOADS_DIR), filename=a_name)
                                 out_name = f"{download_id}.mp4"
                                 out_path = DOWNLOADS_DIR / out_name
                                 cmd = [ffmpeg_exe, "-y", "-i", v_path, "-i", a_path, "-c:v", "copy", "-c:a", "aac", str(out_path)]
                                 if os.name == 'nt':
                                     si = subprocess.STARTUPINFO()
                                     si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                                     subprocess.check_call(cmd, startupinfo=si)
                                 else:
                                     subprocess.check_call(cmd)
                                 try:
                                    os.remove(v_path)
                                    os.remove(a_path)
                                 except: pass
                                 return str(out_path), video_stream.resolution

                    if not stream:
                        stream = yt.streams.get_highest_resolution() 
                    if not stream: 
                        stream = yt.streams.filter(progressive=True).first()
                    ext = ".mp4"
                
                if not stream: raise Exception("No suitable stream found")
                out_path = stream.download(output_path=str(DOWNLOADS_DIR), filename=f"{download_id}{ext}")
                res = stream.resolution if hasattr(stream, 'resolution') else "audio"
                return out_path, res

            filepath, actual_quality = await asyncio.get_event_loop().run_in_executor(executor, download_pytube, download_id)
            filename = os.path.basename(filepath)
            
            if format == "mp3" and not filename.endswith(".mp3"):
                new_path = os.path.splitext(filepath)[0] + ".mp3"
                os.rename(filepath, new_path)
                filepath = new_path
                filename = os.path.basename(new_path)

        else:
            # yt-dlp logic
            ydl_opts = {
                'outtmpl': str(DOWNLOADS_DIR / f'{download_id}.%(ext)s'),
                'quiet': False,
                'ffmpeg_location': ffmpeg_exe if ffmpeg_exe else None
            }
            if format == "mp3":
                if ffmpeg_exe:
                    ydl_opts['format'] = 'bestaudio/best'
                    ydl_opts['postprocessors'] = [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3'}]
                else:
                    ydl_opts['format'] = 'bestaudio/best'
            else:
                 ydl_opts['format'] = 'best' 

            def download_ytdlp():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url_str, download=True)
                    return ydl.prepare_filename(info)

            initial_filepath = await asyncio.get_event_loop().run_in_executor(executor, download_ytdlp)
            found_file = None
            for f in DOWNLOADS_DIR.glob(f"{download_id}.*"):
                found_file = str(f)
                break
            if found_file:
                filepath = found_file
                filename = os.path.basename(filepath)
            else:
                 filepath = initial_filepath
                 filename = os.path.basename(filepath)

        if not os.path.exists(filepath):
            raise Exception("File not found after download")

        # In Server Mode, we must clean up the file after sending
        if IS_SERVER:
            background_tasks.add_task(cleanup_file, filepath)

        # Return File Directly
        return FileResponse(
            path=filepath, 
            filename=filename, 
            media_type='application/octet-stream',
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"'
            }
        )

    except Exception as e:
        logger.error(f"Download invalid: {e}")
        # Return strict error usually, but for browser generic usage maybe just text?
        return f"Error: {e}"

@app.post("/video/download")
async def download_video(request: DownloadRequest):
    url_str = str(request.url)
    download_id = str(uuid.uuid4())
    
    # Check for FFmpeg in current directory or PATH
    ffmpeg_exe = "ffmpeg"
    local_ffmpeg = BASE_DIR / "ffmpeg.exe"
    if local_ffmpeg.exists():
        ffmpeg_exe = str(local_ffmpeg)
    elif shutil.which("ffmpeg"):
         ffmpeg_exe = "ffmpeg"
    else:
         ffmpeg_exe = None
    
    try:
        filename = ""
        filepath = ""
        warning_msg = None
        
        # Flag to indicate if we should fallback to yt-dlp
        use_ytdlp_fallback = False
        
        if is_youtube_url(url_str):
            try:
                # --- YOUTUBE DOWNLOAD (PYTUBEFIX) ---
                def download_pytube(download_id):
                    # Try with OAuth allowed to potentially fix bot issues if user authenticates
                    yt = YouTube(url_str, use_oauth=True, allow_oauth_cache=True)
                    stream = None
                    merged_path = None
                    final_res = None
                    
                    if request.format == "mp3":
                        stream = yt.streams.get_audio_only()
                        ext = ".m4a" 
                    else:
                        # VIDEO HANDLING
                        target_res = request.quality
                        
                        # 1. Try Progressive (simplest, fastest)
                        if target_res:
                            stream = yt.streams.filter(res=target_res, progressive=True).first()
                        
                        # 2. Try Adaptive (DASH) + Merge if Progressive failed and FFmpeg available
                        if not stream and ffmpeg_exe and target_res:
                             # Find video only stream
                             video_stream = yt.streams.filter(res=target_res, adaptive=True).first()
                             
                             if video_stream:
                                 audio_stream = yt.streams.get_audio_only()
                                 if audio_stream:
                                     # Download parts
                                     logger.info(f"Downloading adaptive streams: {video_stream.resolution} video + audio")
                                     v_name = f"v_{download_id}_{video_stream.resolution}.mp4"
                                     a_name = f"a_{download_id}.m4a"
                                     
                                     v_path = video_stream.download(output_path=str(DOWNLOADS_DIR), filename=v_name)
                                     a_path = audio_stream.download(output_path=str(DOWNLOADS_DIR), filename=a_name)
                                     
                                     # Merge
                                     out_name = f"{download_id}.mp4"
                                     out_path = DOWNLOADS_DIR / out_name
                                     
                                     cmd = [
                                         ffmpeg_exe, "-y",
                                         "-i", v_path,
                                         "-i", a_path,
                                         "-c:v", "copy",
                                         "-c:a", "aac", 
                                         str(out_path)
                                     ]
                                     
                                     if os.name == 'nt':
                                         # Hide console window on Windows
                                         si = subprocess.STARTUPINFO()
                                         si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                                         subprocess.check_call(cmd, startupinfo=si)
                                     else:
                                         subprocess.check_call(cmd)
                                         
                                     # Cleanup
                                     try:
                                        os.remove(v_path)
                                        os.remove(a_path)
                                     except: pass
                                     
                                     return str(out_path), video_stream.resolution
    
                        # 3. Fallback to Highest Progressive
                        if not stream:
                            stream = yt.streams.get_highest_resolution() 
                        if not stream: 
                            stream = yt.streams.filter(progressive=True).first()
                            
                        ext = ".mp4"
                    
                    if not stream: raise Exception("No suitable stream found")
                    
                    # Download Progressive / Audio
                    out_path = stream.download(output_path=str(DOWNLOADS_DIR), filename=f"{download_id}{ext}")
                    # For audio downloads, resolution is None, maybe use bitrate?
                    res = stream.resolution if hasattr(stream, 'resolution') else "audio"
                    return out_path, res
    
                filepath, actual_quality = await asyncio.get_event_loop().run_in_executor(executor, download_pytube, download_id)
                filename = os.path.basename(filepath)
                
                # Simple Rename for mp3 request (if user really wants .mp3 extension primarily)
                if request.format == "mp3" and not filename.endswith(".mp3"):
                    new_path = os.path.splitext(filepath)[0] + ".mp3"
                    os.rename(filepath, new_path)
                    filepath = new_path
                    filename = os.path.basename(new_path)
    
                if request.quality and actual_quality and actual_quality != request.quality and request.format != "mp3":
                     warning_msg = f"Requested {request.quality} not available. Downloaded {actual_quality} instead."
            
            except Exception as e:
                logger.warning(f"Pytubefix failed: {e}. Falling back to yt-dlp.")
                use_ytdlp_fallback = True

        if not is_youtube_url(url_str) or use_ytdlp_fallback:
            # --- FACEBOOK/OTHER DOWNLOAD (YT-DLP) ---
            has_ffmpeg = ffmpeg_exe is not None
            ydl_opts = {
                'outtmpl': str(DOWNLOADS_DIR / f'{download_id}.%(ext)s'),
                'quiet': False,
                'ffmpeg_location': ffmpeg_exe if ffmpeg_exe else None
            }
            
            # Simple configuration for robustness
            if request.format == "mp3":
                if has_ffmpeg:
                    ydl_opts['format'] = 'bestaudio/best'
                    ydl_opts['postprocessors'] = [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3'}]
                else:
                    ydl_opts['format'] = 'bestaudio/best' # Will likely download m4a/webm
            else:
                 ydl_opts['format'] = 'best' # Let yt-dlp decide best single file for generic sites

            def download_ytdlp():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url_str, download=True)
                    return ydl.prepare_filename(info)

            # Run download
            initial_filepath = await asyncio.get_event_loop().run_in_executor(executor, download_ytdlp)
            
            # yt-dlp might change extension
            # Find the file that starts with download_id
            found_file = None
            for f in DOWNLOADS_DIR.glob(f"{download_id}.*"):
                found_file = str(f)
                break
                
            if found_file:
                filepath = found_file
                filename = os.path.basename(filepath)
                # If mp3 requested but no ffmpeg, we might have m4a. Rename if desired, but risky. 
                # Let's keep original ext to be safe.
            else:
                 # fallback if simple glob failed (maybe filename didn't use id?)
                 filepath = initial_filepath
                 filename = os.path.basename(filepath)

        if not os.path.exists(filepath):
            raise Exception("File not found after download")

        response_data = {
            "download_id": download_id,
            "filename": filename,
            "filepath": filepath, # Absolute path on local PC
            "filesize": os.path.getsize(filepath),
            "is_saved_locally": True,
            "local_path": str(filepath) 
        }
        
        if warning_msg:
            response_data["warning"] = warning_msg

        return {
            "success": True,
            "data": response_data
        }

    except Exception as e:
        logger.error(f"Download invalid: {e}")
        raise HTTPException(status_code=400, detail=f"Download failed: {str(e)}")

@app.get("/video/file/{filename}")
async def get_file(filename: str):
    # Try finding in Downloads dir
    file_path = DOWNLOADS_DIR / filename
    if not file_path.exists():
         raise HTTPException(status_code=404, detail="File not found")
    
    # Force attachment to ensure download behavior across browsers
    return FileResponse(
        path=file_path, 
        filename=filename, 
        media_type='application/octet-stream',
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Access-Control-Expose-Headers": "Content-Disposition"
        }
    )

@app.get("/health")
async def health_check():
    return {"status": "healthy", "mode": "Hybrid (Pytubefix + yt-dlp)"}

if __name__ == "__main__":
    import uvicorn
    import webbrowser
    webbrowser.open("http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
